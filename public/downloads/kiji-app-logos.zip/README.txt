Official KiJi logo assets (Circle).

kiji-logo-light-1024.png / kiji-logo-dark-1024.png  App icon, transparent 1024x1024, for light / dark backgrounds.
kiji-mark-light-*  Mark filling the canvas, for light backgrounds.
kiji-mark-dark-*   Mark filling the canvas, for dark backgrounds.
app-icons/kiji-icon-*.png  Every app icon offered in KiJi Settings, transparent 1024x1024.

Website: https://kiji.yomilab.app
