Official KiJi logo assets (Ripple).

kiji-logo-light-1024.png / kiji-logo-dark-1024.png  App icon with its plate, transparent 1024x1024.
kiji-mark-light-*  Mark without plate, for light backgrounds.
kiji-mark-dark-*   Mark without plate, for dark backgrounds.

Website: https://kiji.yomilab.app
