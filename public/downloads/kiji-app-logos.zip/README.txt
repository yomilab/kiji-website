Official KiJi app logo assets.
Website: https://kiji.yomilab.app
