Official KiJi app logo assets (sunset theme is the website default light/dark pair).
Website: https://kiji.yomilab.app
