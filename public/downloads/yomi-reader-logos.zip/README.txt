Official Yomi Reader logo assets (Circle).

yomi-reader-logo-light-1024.png / yomi-reader-logo-dark-1024.png  App icon, transparent 1024x1024, for light / dark backgrounds.
yomi-reader-mark-light-*  Mark filling the canvas, for light backgrounds.
yomi-reader-mark-dark-*   Mark filling the canvas, for dark backgrounds.
app-icons/yomi-reader-icon-*.png  Every app icon offered in Yomi Reader Settings, transparent 1024x1024.

Website: https://kiji.yomilab.app
